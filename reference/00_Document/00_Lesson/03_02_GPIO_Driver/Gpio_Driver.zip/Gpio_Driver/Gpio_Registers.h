#ifndef GPIO_REGISTER_H
#define GPIO_REGISTER_H

/** GPIO - Register Layout Typedef */
typedef struct {
    volatile unsigned int PDOR;
	volatile unsigned int PSOR;
	volatile unsigned int PCOR;
	volatile unsigned int PTOR;
	volatile const unsigned int PDIR;
	volatile unsigned int PDDR;
	volatile unsigned int PIDR;
} GPIO_Type;

/** Peripheral GPIOA base address */
#define GPIOD_BASE                               (0x400FF0C0u)

/** Peripheral GPIOA base pointer */
#define GPIOD    ((GPIO_Type *)GPIOD_BASE)

#endif
